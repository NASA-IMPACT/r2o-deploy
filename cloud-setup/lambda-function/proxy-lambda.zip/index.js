const https = require('https');
const http = require('http');
const url = require('url');

/**
 * Lambda function that acts as a proxy to restricted servers
 */
exports.handler = async (event) => {
  console.log('Event:', JSON.stringify(event, null, 2));
  
  // Get target server from environment variable or event
  const targetServer = event.targetServer || process.env.TARGET_SERVER;
  
  if (!targetServer) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: 'Target server not specified' })
    };
  }
  
  // Parse request details
  const requestMethod = event.httpMethod || 'GET';
  const requestPath = event.path || '/';
  const requestBody = event.body || '';
  const requestHeaders = event.headers || {};
  
  // Create options for the request
  const parsedUrl = url.parse(targetServer + requestPath);
  const options = {
    hostname: parsedUrl.hostname,
    port: parsedUrl.port || (parsedUrl.protocol === 'https:' ? 443 : 80),
    path: parsedUrl.path,
    method: requestMethod,
    headers: requestHeaders
  };
  
  try {
    // Execute the request
    const response = await makeRequest(options, requestBody);
    
    return {
      statusCode: response.statusCode,
      headers: response.headers,
      body: response.body
    };
  } catch (error) {
    console.error('Error:', error);
    
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Failed to proxy request', details: error.message })
    };
  }
};

/**
 * Helper function to make HTTP/HTTPS requests
 */
function makeRequest(options, body) {
  return new Promise((resolve, reject) => {
    const protocol = options.port === 443 ? https : http;
    
    const req = protocol.request(options, (res) => {
      let responseBody = '';
      
      res.on('data', (chunk) => {
        responseBody += chunk;
      });
      
      res.on('end', () => {
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          body: responseBody
        });
      });
    });
    
    req.on('error', (error) => {
      reject(error);
    });
    
    if (body) {
      req.write(body);
    }
    
    req.end();
  });
}